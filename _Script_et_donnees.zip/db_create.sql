-- Database: Projet6
-- Author: Vincent
CREATE DATABASE ocpizza
	WITH OWNER = postgres
		ENCODING = 'UTF8'
		TABLESPACE = pg_default
		LC_COLLATE = 'fr_FR.UTF-8'
		LC_CTYPE = 'fr_FR.UTF-8'
		CONNECTION LIMIT = -1;